#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
超参数搜索脚本 - 用于批量训练和评估
对每个参数候选值分别训练模型3次，记录结果

使用方法：
    python hyperparameter_search.py --param_name lr --param_values 0.00001 0.0001 0.0005
"""

import os
import sys
import argparse
import subprocess
import json
from datetime import datetime
from pathlib import Path


class HyperparameterSearch:
    def __init__(self, param_name, param_values, num_runs=3, niter=50, niter_decay=50):
        self.param_name = param_name
        self.param_values = param_values
        self.num_runs = num_runs
        self.niter = niter
        self.niter_decay = niter_decay
        
        # 创建结果目录
        self.base_results_dir = './hyperparameter_results'
        self.experiment_dir = os.path.join(
            self.base_results_dir, 
            f"{param_name}_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        )
        os.makedirs(self.experiment_dir, exist_ok=True)
        
        # 初始化结果记录
        self.results = {
            'param_name': param_name,
            'param_values': param_values,
            'num_runs': num_runs,
            'timestamp': datetime.now().isoformat(),
            'experiments': {}
        }
        
    def get_checkpoint_name(self, param_value, run_id):
        """
        生成模型检查点的名称
        格式: {param_name}_{param_value}_{run_id}
        例: lr_0.0001_run1
        """
        return f"{self.param_name}_{param_value}_run{run_id}"
    
    def train_model(self, param_value, run_id):
        """
        训练单个模型
        
        参数:
            param_value: 参数值
            run_id: 运行ID (1, 2, 3 等)
        
        返回:
            bool: 训练是否成功
        """
        checkpoint_name = self.get_checkpoint_name(param_value, run_id)
        
        print(f"\n{'='*70}")
        print(f"[{self.param_name}={param_value}] 运行 {run_id}/{self.num_runs}")
        print(f"模型名称: {checkpoint_name}")
        print(f"{'='*70}\n")
        
        # 构建训练命令
        cmd = [
            'python', 'train.py',
            '--name', checkpoint_name,
            '--dataroot', 'my_datasets',
            '--niter', str(self.niter),
            '--niter_decay', str(self.niter_decay),
        ]
        
        # 添加参数值
        if self.param_name == 'lr':
            cmd.extend(['--lr', str(param_value)])
        elif self.param_name == 'gama_physics':
            cmd.extend(['--gama_physics', str(param_value)])
        elif self.param_name == 'gama_small_wall':
            cmd.extend(['--gama_small_wall', str(param_value)])
        elif self.param_name == 'lambda_feat':
            cmd.extend(['--lambda_feat', str(param_value)])
        elif self.param_name == 'gama_txt_G':
            cmd.extend(['--gama_txt_G', str(param_value)])
        elif self.param_name == 'gama_txt_D':
            cmd.extend(['--gama_txt_D', str(param_value)])
        elif self.param_name == 'physics_epoch1':
            cmd.extend(['--physics_epoch1', str(param_value)])
        elif self.param_name == 'physics_epoch2':
            cmd.extend(['--physics_epoch2', str(param_value)])
        elif self.param_name == 'small_wall_epoch1':
            cmd.extend(['--small_wall_epoch1', str(param_value)])
        elif self.param_name == 'small_wall_epoch2':
            cmd.extend(['--small_wall_epoch2', str(param_value)])
        elif self.param_name == 'num_D':
            cmd.extend(['--num_D', str(int(param_value))])
        elif self.param_name == 'n_layers_D':
            cmd.extend(['--n_layers_D', str(int(param_value))])
        elif self.param_name == 'ngf':
            cmd.extend(['--ngf', str(int(param_value))])
        elif self.param_name == 'ndf':
            cmd.extend(['--ndf', str(int(param_value))])
        elif self.param_name == 'n_blocks_global':
            cmd.extend(['--n_blocks_global', str(int(param_value))])
        elif self.param_name == 'n_downsample_global':
            cmd.extend(['--n_downsample_global', str(int(param_value))])
        elif self.param_name == 'n_blocks_txt':
            cmd.extend(['--n_blocks_txt', str(int(param_value))])
        elif self.param_name == 'physics_constraint_type':
            cmd.extend(['--physics_constraint_type', str(param_value)])
        elif self.param_name == 'period_max_weight':
            cmd.extend(['--period_max_weight', str(float(param_value))])
        else:
            # 通用方式：假设参数名称直接对应命令行参数
            cmd.extend([f'--{self.param_name}', str(param_value)])
        
        # 执行训练命令
        try:
            result = subprocess.run(cmd, check=True)
            print(f"\n✓ {checkpoint_name} 训练完成")
            return True
        except subprocess.CalledProcessError as e:
            print(f"\n✗ {checkpoint_name} 训练失败: {e}")
            return False
    
    def collect_training_info(self, param_value, run_id):
        """
        收集训练信息
        
        参数:
            param_value: 参数值
            run_id: 运行ID
        
        返回:
            dict: 训练信息
        """
        checkpoint_name = self.get_checkpoint_name(param_value, run_id)
        checkpoint_dir = os.path.join('./checkpoints', checkpoint_name)
        
        info = {
            'checkpoint_name': checkpoint_name,
            'checkpoint_dir': checkpoint_dir,
            'param_value': param_value,
            'run_id': run_id,
            'exists': os.path.exists(checkpoint_dir),
        }
        
        # 尝试读取损失日志
        loss_log_path = os.path.join(checkpoint_dir, 'loss_log.txt')
        if os.path.exists(loss_log_path):
            try:
                with open(loss_log_path, 'r') as f:
                    lines = f.readlines()
                    if lines:
                        # 获取最后一行的信息
                        last_line = lines[-1].strip()
                        info['last_loss_log'] = last_line
            except Exception as e:
                info['error_reading_loss_log'] = str(e)
        
        return info
    
    def run_search(self):
        """
        执行超参数搜索
        """
        print(f"\n{'#'*70}")
        print(f"# 超参数搜索: {self.param_name}")
        print(f"# 候选值: {self.param_values}")
        print(f"# 每个值训练次数: {self.num_runs}")
        print(f"# 结果保存目录: {self.experiment_dir}")
        print(f"{'#'*70}\n")
        
        for param_value in self.param_values:
            self.results['experiments'][str(param_value)] = {
                'param_value': param_value,
                'runs': []
            }
            
            for run_id in range(1, self.num_runs + 1):
                # 训练模型
                success = self.train_model(param_value, run_id)
                
                # 收集信息
                info = self.collect_training_info(param_value, run_id)
                info['success'] = success
                
                self.results['experiments'][str(param_value)]['runs'].append(info)
                
                # 保存中间结果
                self.save_results()
        
        print(f"\n{'='*70}")
        print("超参数搜索完成！")
        print(f"{'='*70}\n")
        
        # 打印总结
        self.print_summary()
    
    def save_results(self):
        """
        保存结果到JSON文件
        """
        results_file = os.path.join(self.experiment_dir, 'results.json')
        with open(results_file, 'w', encoding='utf-8') as f:
            json.dump(self.results, f, indent=2, ensure_ascii=False)
        print(f"  结果已保存: {results_file}")
    
    def print_summary(self):
        """
        打印搜索结果总结
        """
        print(f"\n{'='*70}")
        print("搜索结果总结")
        print(f"{'='*70}\n")
        
        print(f"参数名称: {self.param_name}")
        print(f"实验目录: {self.experiment_dir}\n")
        
        for param_value in self.param_values:
            runs_info = self.results['experiments'][str(param_value)]['runs']
            successful_runs = sum(1 for run in runs_info if run['success'])
            
            print(f"参数值: {param_value}")
            print(f"  成功训练: {successful_runs}/{self.num_runs}")
            for run_info in runs_info:
                status = "✓" if run_info['success'] else "✗"
                print(f"    {status} {run_info['checkpoint_name']}")
                if 'last_loss_log' in run_info:
                    print(f"       最后损失: {run_info['last_loss_log'][:80]}")
            print()
        
        print(f"详细结果已保存至: {os.path.join(self.experiment_dir, 'results.json')}\n")


def parse_arguments():
    """
    解析命令行参数
    """
    parser = argparse.ArgumentParser(
        description='超参数搜索和批量训练脚本',
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    
    parser.add_argument(
        '--param_name',
        type=str,
        required=True,
        help='参数名称 (例: lr, gama_physics, gama_small_wall, lambda_feat, 等)'
    )
    
    parser.add_argument(
        '--param_values',
        type=float,
        nargs='+',
        required=True,
        help='参数候选值列表 (例: 0.00001 0.0001 0.0005)'
    )
    
    parser.add_argument(
        '--num_runs',
        type=int,
        default=1,
        help='每个参数值的训练次数 (默认: 3)'
    )
    
    parser.add_argument(
        '--niter',
        type=int,
        default=300,
        help='学习率不变的迭代次数 (默认: 50)'
    )
    
    parser.add_argument(
        '--niter_decay',
        type=int,
        default=300,
        help='学习率线性衰减的迭代次数 (默认: 50)'
    )
    
    return parser.parse_args()


if __name__ == '__main__':
    args = parse_arguments()
    
    # 创建搜索对象
    search = HyperparameterSearch(
        param_name=args.param_name,
        param_values=args.param_values,
        num_runs=args.num_runs,
        niter=args.niter,
        niter_decay=args.niter_decay
    )
    
    # 执行搜索
    search.run_search()
