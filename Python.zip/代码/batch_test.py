#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
批量测试脚本 - 对应超参数搜索的训练结果
自动扫描所有训练好的模型并进行测试

使用方法：
    python batch_test.py --param_name lr
    python batch_test.py --checkpoint_names lr_0.0001_run1 lr_0.0002_run1
"""

import os
import sys
import argparse
import subprocess
from pathlib import Path


class BatchTester:
    def __init__(self, checkpoint_names=None, param_name=None, param_values=None, 
                 dataroot='datasets', how_many=28, which_epoch='latest'):
        self.checkpoint_names = checkpoint_names or []
        self.param_name = param_name
        self.param_values = param_values or []
        self.dataroot = dataroot
        self.how_many = how_many
        self.which_epoch = which_epoch
        
        # 如果指定了参数名和值，生成检查点名称
        if param_name and param_values:
            self.checkpoint_names.extend([
                f"{param_name}_{value}_run1" 
                for value in param_values
            ])
        
        # 测试结果
        self.test_results = {
            'success': [],
            'failed': []
        }
    
    def test_model(self, checkpoint_name):
        """
        测试单个模型
        
        参数:
            checkpoint_name: 检查点名称
        
        返回:
            bool: 测试是否成功
        """
        print(f"\n{'='*70}")
        print(f"测试模型: {checkpoint_name}")
        print(f"{'='*70}\n")
        
        # 检查检查点是否存在
        checkpoint_dir = os.path.join('./checkpoints', checkpoint_name)
        if not os.path.exists(checkpoint_dir):
            print(f"✗ 检查点不存在: {checkpoint_dir}")
            return False
        
        # 构建测试命令
        cmd = [
            'python', 'test.py',
            '--name', checkpoint_name,
            '--dataroot', self.dataroot,
            '--phase', 'test',
            '--which_epoch', self.which_epoch,
            '--how_many', str(self.how_many),
        ]
        
        # 执行测试命令
        try:
            result = subprocess.run(cmd, check=True, capture_output=True, text=True)
            print(f"\n✓ {checkpoint_name} 测试完成")
            
            # 保存结果信息
            results_dir = os.path.join('./results', checkpoint_name, 'test_latest')
            self.test_results['success'].append({
                'checkpoint_name': checkpoint_name,
                'results_dir': results_dir,
                'output': result.stdout
            })
            
            return True
        except subprocess.CalledProcessError as e:
            print(f"\n✗ {checkpoint_name} 测试失败")
            print(f"错误信息: {e.stderr}")
            
            self.test_results['failed'].append({
                'checkpoint_name': checkpoint_name,
                'error': str(e),
                'stderr': e.stderr
            })
            
            return False
    
    def run_batch_test(self):
        """
        执行批量测试
        """
        print(f"\n{'#'*70}")
        print(f"# 批量测试")
        print(f"# 待测试模型数量: {len(self.checkpoint_names)}")
        print(f"# 数据集: {self.dataroot}")
        print(f"# 测试样本数: {self.how_many}")
        print(f"{'#'*70}\n")
        
        for i, checkpoint_name in enumerate(self.checkpoint_names, 1):
            print(f"\n[{i}/{len(self.checkpoint_names)}] 开始测试...")
            self.test_model(checkpoint_name)
        
        print(f"\n{'='*70}")
        print("批量测试完成！")
        print(f"{'='*70}\n")
        
        # 打印总结
        self.print_summary()
    
    def print_summary(self):
        """
        打印测试结果总结
        """
        print(f"\n{'='*70}")
        print("测试结果总结")
        print(f"{'='*70}\n")
        
        total = len(self.checkpoint_names)
        success_count = len(self.test_results['success'])
        failed_count = len(self.test_results['failed'])
        
        print(f"总计: {total} 个模型")
        print(f"成功: {success_count} 个")
        print(f"失败: {failed_count} 个\n")
        
        if self.test_results['success']:
            print("成功的模型:")
            for result in self.test_results['success']:
                print(f"  ✓ {result['checkpoint_name']}")
                print(f"    结果目录: {result['results_dir']}")
            print()
        
        if self.test_results['failed']:
            print("失败的模型:")
            for result in self.test_results['failed']:
                print(f"  ✗ {result['checkpoint_name']}")
                print(f"    错误: {result['error']}")
            print()
        
        print(f"\n查看测试结果:")
        print(f"  - 图片结果: ./results/<checkpoint_name>/test_latest/images/")
        print(f"  - 网页结果: ./results/<checkpoint_name>/test_latest/index.html\n")


def scan_checkpoints(param_name=None):
    """
    扫描 checkpoints 目录，查找所有检查点
    
    参数:
        param_name: 参数名（可选），用于过滤检查点
    
    返回:
        list: 检查点名称列表
    """
    checkpoints_dir = './checkpoints'
    
    if not os.path.exists(checkpoints_dir):
        print(f"警告: 检查点目录不存在: {checkpoints_dir}")
        return []
    
    checkpoint_names = []
    
    for item in os.listdir(checkpoints_dir):
        item_path = os.path.join(checkpoints_dir, item)
        
        # 只处理目录
        if os.path.isdir(item_path):
            # 如果指定了参数名，进行过滤
            if param_name and not item.startswith(f"{param_name}_"):
                continue
            
            checkpoint_names.append(item)
    
    checkpoint_names.sort()
    return checkpoint_names


def parse_arguments():
    """
    解析命令行参数
    """
    parser = argparse.ArgumentParser(
        description='批量测试脚本',
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    
    parser.add_argument(
        '--checkpoint_names',
        type=str,
        nargs='+',
        help='要测试的检查点名称列表'
    )
    
    parser.add_argument(
        '--param_name',
        type=str,
        help='参数名（用于自动生成检查点名称）'
    )
    
    parser.add_argument(
        '--param_values',
        type=float,
        nargs='+',
        help='参数值列表（配合 param_name 使用）'
    )
    
    parser.add_argument(
        '--scan_all',
        action='store_true',
        help='扫描所有检查点进行测试'
    )
    
    parser.add_argument(
        '--dataroot',
        type=str,
        default='datasets/structs',
        help='数据集目录'
    )
    
    parser.add_argument(
        '--how_many',
        type=int,
        default=96,
        help='测试样本数量'
    )
    
    parser.add_argument(
        '--which_epoch',
        type=str,
        default='latest',
        help='加载哪个epoch的模型'
    )
    
    return parser.parse_args()


if __name__ == '__main__':
    args = parse_arguments()
    
    # 如果扫描所有检查点
    if args.scan_all:
        checkpoint_names = scan_checkpoints(args.param_name)
        print(f"扫描到 {len(checkpoint_names)} 个检查点")
    else:
        checkpoint_names = args.checkpoint_names
    
    # 创建测试器
    tester = BatchTester(
        checkpoint_names=checkpoint_names,
        param_name=args.param_name,
        param_values=args.param_values,
        dataroot=args.dataroot,
        how_many=args.how_many,
        which_epoch=args.which_epoch
    )
    
    # 执行批量测试
    tester.run_batch_test()
