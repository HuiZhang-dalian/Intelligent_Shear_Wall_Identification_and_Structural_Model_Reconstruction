import torch
import torch.nn as nn

class RelativeDriftLoss(nn.Module):
    """
    相对层间位移角损失模块
    基于等效悬臂梁模型，计算结构布局的位移角
    """
    def __init__(self, epsilon=1e-6, shear_wall_threshold=0.5):
        super(RelativeDriftLoss, self).__init__()
        self.epsilon = epsilon
        self.shear_wall_threshold = shear_wall_threshold
    
    def forward(self, layout):
        """
        计算相对层间位移角损失
        
        参数:
            layout: 生成的剪力墙布局图像，尺寸为(Batch_Size, 1, H, W)
            值在[0, 1]之间，表示材料密度概率
        
        返回:
            loss: 相对层间位移角损失
        """
        batch_size, _, height, width = layout.size()
        
        # 过滤出剪力墙: 只保留值大于阈值的像素
        shear_wall_layout = torch.where(layout > self.shear_wall_threshold, layout, torch.zeros_like(layout))
        
        # 1. 计算总质量 M: 所有剪力墙像素值的总和
        # 对每个样本，计算所有剪力墙像素的和
        M = shear_wall_layout.sum(dim=(1, 2, 3))  # 输出尺寸: (batch_size,)
        
        # 2. 计算质心 (Cx, Cy)
        # 创建坐标网格
        # x坐标: 0到width-1，形状为(1, 1, 1, width)
        x_coords = torch.arange(width, device=layout.device, dtype=layout.dtype).view(1, 1, 1, width)
        # y坐标: 0到height-1，形状为(1, 1, height, 1)
        y_coords = torch.arange(height, device=layout.device, dtype=layout.dtype).view(1, 1, height, 1)
        
        # 计算x方向质心: sum(shear_wall_pixel * x) / M
        sum_x = (shear_wall_layout * x_coords).sum(dim=(1, 2, 3))  # 输出尺寸: (batch_size,)
        Cx = sum_x / (M + self.epsilon)  # 防止除以零
        
        # 计算y方向质心: sum(shear_wall_pixel * y) / M
        sum_y = (shear_wall_layout * y_coords).sum(dim=(1, 2, 3))  # 输出尺寸: (batch_size,)
        Cy = sum_y / (M + self.epsilon)  # 防止除以零
        
        # 3. 计算截面惯性矩 I
        # Ixx (抵抗Y方向侧移) = sum(shear_wall_pixel * (y - Cy)^2)
        # 扩展Cy维度以匹配layout的维度: (batch_size,) -> (batch_size, 1, height, 1)
        Cy_expanded = Cy.view(batch_size, 1, 1, 1)
        y_diff = y_coords - Cy_expanded  # 形状: (batch_size, 1, height, width)
        Ixx = (shear_wall_layout * y_diff ** 2).sum(dim=(1, 2, 3))  # 输出尺寸: (batch_size,)
        
        # Iyy (抵抗X方向侧移) = sum(shear_wall_pixel * (x - Cx)^2)
        # 扩展Cx维度以匹配layout的维度: (batch_size,) -> (batch_size, 1, 1, width)
        Cx_expanded = Cx.view(batch_size, 1, 1, 1)
        x_diff = x_coords - Cx_expanded  # 形状: (batch_size, 1, height, width)
        Iyy = (shear_wall_layout * x_diff ** 2).sum(dim=(1, 2, 3))  # 输出尺寸: (batch_size,)
        
        # 4. 计算位移角 Drift
        # Driftx = M / (Iyy + epsilon) (X方向位移由绕Y轴的惯性矩控制)
        Driftx = M / (Iyy + self.epsilon)
        
        # Drifty = M / (Ixx + epsilon)
        Drifty = M / (Ixx + self.epsilon)
        
        # 5. 计算最终Loss
        # 取X和Y方向位移角中的最大值
        max_drift = torch.max(Driftx, Drifty)
        
        # 乘以缩放系数 (H * W) 以保持数值量级合理
        scale_factor = height * width
        loss = max_drift * scale_factor
        
        # 对batch内的loss取平均值
        loss = loss.mean()
        
        return loss


class SmallWallRegLoss(nn.Module):
    """
    限制较小剪力墙的正则项：鼓励质量集中、抑制碎片化小墙。
    思路：浓度 = sum(x^2)/sum(x)，质量越集中（少而大的墙）越大，越分散（多而小的墙）越小。
    最小化 -浓度 等价于最大化浓度，起到正则化作用。
    腐蚀项，惩罚“薄墙”（腐蚀后损失质量多的布局）。
    """
    def __init__(self, epsilon=1e-6, shear_wall_threshold=0.5, use_erosion=True, erosion_kernel=3):
        super(SmallWallRegLoss, self).__init__()
        self.epsilon = epsilon
        self.shear_wall_threshold = shear_wall_threshold
        self.use_erosion = use_erosion
        self.erosion_kernel = erosion_kernel

    def forward(self, layout):
        """
        layout: (B, 1, H, W)，[0,1] 剪力墙密度
        """
        # 与物理 loss 一致：只计大于阈值的剪力墙像素
        shear_wall = torch.where(layout > self.shear_wall_threshold, layout, torch.zeros_like(layout))
        M = shear_wall.sum(dim=(1, 2, 3)) + self.epsilon  # (B,)

        # 浓度正则：- sum(x^2)/sum(x)，最小化即最大化浓度
        sum_sq = (shear_wall ** 2).sum(dim=(1, 2, 3))  # (B,)
        concentration = sum_sq / M  # 越大越集中
        loss_conc = -concentration.mean()  # 最小化 -浓度 → 鼓励集中

        if not self.use_erosion or M.numel() == 0:
            return loss_conc

        # 腐蚀项：薄墙腐蚀后损失多，惩罚“薄”
        # 腐蚀 ≈ 局部最小：eroded = -F.max_pool2d(-x, k)
        k = self.erosion_kernel
        padded = torch.nn.functional.pad(shear_wall, (k//2, k//2, k//2, k//2), mode='constant', value=0)
        eroded = -torch.nn.functional.max_pool2d(-padded, kernel_size=k, stride=1)
        M_eroded = eroded.sum(dim=(1, 2, 3)) + self.epsilon
        thinness = (M - M_eroded) / M  # 薄则 thinness 大
        loss_erosion = thinness.mean()

        return loss_conc + loss_erosion
